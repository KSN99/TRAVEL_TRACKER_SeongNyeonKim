# CP1404 Assignment 2 - Travel tracker 2.0 by SeongNyeon Kim

This assignment was developing GUI program to display places list that is showing the status of visiting requirement
or adding a new places to visit. Users can see the status message, and change the status whether the place has visited
or not by simply clicking the buttons of each places. They can sort places by title, country, and priority as well. Also,
when users want to add a new place, they can just fill up the text fields, and click the 'add place' button. Error
messages will be displayed whenever the users make input errors. They also can clear text fields by simply clicking
the 'clear' button. .


# Project Reflection

## 1. How long did the entire project (assignment 2) take you?

   The entire project took me 6 days to complete. Based on WakaTime, I spent around 26 hours in total including all
the trials and errors. The day I spend was shorter, but the hours taken were longer than the previous assignment.
And according to the graph, I spent more than a half of the total hours in two days. It means that I did not distribute
my work well. Based on this experience, I will do better at planning when I do the similar project in the future.

## 2. What are you most satisfied with?

 The most satisfied part of this assignment was to create a GUI program (by using kivy) that was quite more interesting
than the assignment1 which does not need the graphical interface. Although my program was not very perfect, it was
really interesting to create a simple app that can interact with users. To be honest, it was not really easy,
but I have learned a lot how to create graphical user interface, how to use the classes, how to organize the functions,
and perseverance from a bunch of trials and errors.

## 3. What are you least satisfied with?
    The least satisfied part of the process of this assignment was time management and some parts that I couldn't find
the solutions. After I completed the assignment1 successfully, I was a bit proud of myself and earned some kind of
confidence because I made it for the first python work. It was a great motivation for programming, however,
at the same time I was a bit unaware of the next assignment will be way harder. At the same time,
since some holidays and other assignments, I started this assignment quite late. Thus I could not have time
to think deeply and plan precisely for the build this project. Therefore I was not able to complete this assignment
to be looked like what I desired, and it remains a lot in my mind.

## 4. What worked well in your development process?
    I face a lot of obstacles when I am working on my assignment, I was trying to install Kivy for a while. Eventually, 
    I feel really surprise at that time. I thought I have no ability to do the python with the graphical control.
     and after that I help serval people for installing Kivy. I am feeling well by during helping others. 


## 5. What about your process could be improved the next time you do a project like this?
    I think I need to learn more things in advance, by doing this I can do my assignment quicker and also using least word and function to finish that. 
    Rumor says that, the programmer three is focus on the java language, so had better learn the language as early as I can. 
    I think I will start from the online tutorial. If I am facing some difficulty, I will try to ask my lecture and some of my friend. 
    I know in the advance area of python people aiming for lease code to do more thing. 
    In the future job, I might code tens of thousands of the code in project, if my code is long and not simplify it will
     consume lots of memory space and drag down the running speed of my project.  This is what I am aiming for as well. 

## 6. Describe what learning resources you used and how you used them.

    I used to review the lecture’s side and during the class I try to do lots of memo and make sure I know everything from the lecture slide.
     Moreover, If I have problem in the class, I will also ask my clubmate (ID8), I am part of the member. I used to go their couple times per week for further learning. 

## 7. Describe the main challenges or obstacles you faced and how you overcame them.

    The main challenge for me is I KIVY. Firstly, I never touch this kind of things before, 
    so I don’t know where I should start at the first time. However, I made some research for KIVY. 
    Even watch from the YouTube tutorial for KIVY. All in all I overcome it.  

## 8. Briefly describe your experience using classes and if/how they improved your code.
    I am the student let get really low score in the assignment one because of the used only two function in the assignment after 
    that I fell really regret so this, I really use the class well. 
    Not only because of the higher grade , but also because the well behavior for being a programmer. 
